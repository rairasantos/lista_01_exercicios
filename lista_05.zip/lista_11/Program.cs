﻿/*Ex - 11 - Crie um programa que peça ao usuário para inserir um número inteiro positivo e então conte de 1 até esse número, exibindo cada número.
  O programa deve implementar essa contagem usando while, do while e for.*/

Console.WriteLine("Digite um número");
int número = int.Parse(Console.ReadLine());

int contador = 1;
while (contador <= 1)
{
    Console.WriteLine(contador);
    contador++;
}

