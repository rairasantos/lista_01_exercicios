﻿/*
 9. Dia da Semana (usando if-else)
o Objetivo: Praticar a utilização de múltiplas condições com if, else if e else.
o Descrição: Desenvolva um programa que peça um número de 1 a 7 e exiba
o dia da semana correspondente (1 para "Domingo", 2 para "Segunda-feira",
etc.). Se o número estiver fora desse intervalo, exiba uma mensagem de
erro.
o Exemplo de Saída: "Domingo", "Segunda-feira", etc., ou "Número inválido.
Digite um número de 1 a 7."
*/
Console.WriteLine("Digite um número de 1 a 7:");